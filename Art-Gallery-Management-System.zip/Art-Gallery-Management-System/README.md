# Art Gallery Management System

A web-based Art Gallery Management System built with Python Flask, MySQL, HTML, CSS and JavaScript.

## Features
- Login
- Dashboard
- Artist management
- Artwork management
- Exhibition management
- Inventory management
- Search
- MySQL database

## Run
1. Install Python and MySQL.
2. Run `pip install -r requirements.txt`.
3. Execute `database.sql` in MySQL.
4. In `app.py`, replace `YOUR_MYSQL_PASSWORD` with your MySQL password.
5. Run `python app.py`.
6. Open `http://127.0.0.1:5000`.

Demo login: `admin` / `admin123`
