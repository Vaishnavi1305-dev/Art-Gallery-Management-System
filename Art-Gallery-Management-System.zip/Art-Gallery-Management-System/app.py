from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = "art_gallery_secret_key"

def db():
    return mysql.connector.connect(host="localhost", user="root",
                                   password="YOUR_MYSQL_PASSWORD",
                                   database="art_gallery")

def logged_in():
    return "username" in session

@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        con=db(); cur=con.cursor(dictionary=True)
        cur.execute("SELECT * FROM users WHERE username=%s AND password=%s",
                    (request.form["username"],request.form["password"]))
        user=cur.fetchone(); cur.close(); con.close()
        if user:
            session["username"]=user["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor()
    counts=[]
    for table in ["artworks","artists","exhibitions","inventory"]:
        cur.execute("SELECT COUNT(*) FROM "+table)
        counts.append(cur.fetchone()[0])
    cur.close(); con.close()
    return render_template("dashboard.html", artwork_count=counts[0], artist_count=counts[1],
                           exhibition_count=counts[2], inventory_count=counts[3])

@app.route("/artworks")
def artworks():
    if not logged_in(): return redirect(url_for("login"))
    s=request.args.get("search",""); con=db(); cur=con.cursor(dictionary=True)
    cur.execute("""SELECT artworks.*,artists.name artist_name FROM artworks
                   LEFT JOIN artists ON artworks.artist_id=artists.id
                   WHERE artworks.title LIKE %s OR artists.name LIKE %s ORDER BY artworks.id DESC""",
                ("%"+s+"%","%"+s+"%"))
    rows=cur.fetchall(); cur.close(); con.close()
    return render_template("artworks.html",artworks=rows,search=s)

@app.route("/artworks/add", methods=["GET","POST"])
def add_artwork():
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(dictionary=True); cur.execute("SELECT * FROM artists ORDER BY name"); artists=cur.fetchall()
    if request.method=="POST":
        cur.execute("""INSERT INTO artworks(title,artist_id,category,price,status,description)
                       VALUES(%s,%s,%s,%s,%s,%s)""",
                    tuple(request.form[k] for k in ["title","artist_id","category","price","status","description"]))
        con.commit(); cur.close(); con.close(); flash("Artwork added successfully!")
        return redirect(url_for("artworks"))
    cur.close(); con.close()
    return render_template("add_artwork.html",artists=artists)

@app.route("/artworks/delete/<int:id>")
def delete_artwork(id):
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(); cur.execute("DELETE FROM artworks WHERE id=%s",(id,)); con.commit(); cur.close(); con.close()
    flash("Artwork deleted successfully!"); return redirect(url_for("artworks"))

@app.route("/artists",methods=["GET","POST"])
def artists():
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(dictionary=True)
    if request.method=="POST":
        cur.execute("INSERT INTO artists(name,email,phone,country) VALUES(%s,%s,%s,%s)",
                    tuple(request.form[k] for k in ["name","email","phone","country"])); con.commit(); flash("Artist added successfully!")
    cur.execute("SELECT * FROM artists ORDER BY id DESC"); rows=cur.fetchall(); cur.close(); con.close()
    return render_template("artists.html",artists=rows)

@app.route("/artists/delete/<int:id>")
def delete_artist(id):
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(); cur.execute("DELETE FROM artists WHERE id=%s",(id,)); con.commit(); cur.close(); con.close()
    flash("Artist deleted successfully!"); return redirect(url_for("artists"))

@app.route("/exhibitions",methods=["GET","POST"])
def exhibitions():
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(dictionary=True)
    if request.method=="POST":
        cur.execute("""INSERT INTO exhibitions(name,start_date,end_date,location,description)
                       VALUES(%s,%s,%s,%s,%s)""",
                    tuple(request.form[k] for k in ["name","start_date","end_date","location","description"]))
        con.commit(); flash("Exhibition added successfully!")
    cur.execute("SELECT * FROM exhibitions ORDER BY id DESC"); rows=cur.fetchall(); cur.close(); con.close()
    return render_template("exhibitions.html",exhibitions=rows)

@app.route("/exhibitions/delete/<int:id>")
def delete_exhibition(id):
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(); cur.execute("DELETE FROM exhibitions WHERE id=%s",(id,)); con.commit(); cur.close(); con.close()
    flash("Exhibition deleted successfully!"); return redirect(url_for("exhibitions"))

@app.route("/inventory",methods=["GET","POST"])
def inventory():
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(dictionary=True)
    if request.method=="POST":
        cur.execute("INSERT INTO inventory(artwork_id,quantity,location) VALUES(%s,%s,%s)",
                    (request.form["artwork_id"],request.form["quantity"],request.form["location"]))
        con.commit(); flash("Inventory added successfully!")
    cur.execute("""SELECT inventory.*,artworks.title FROM inventory
                   JOIN artworks ON inventory.artwork_id=artworks.id ORDER BY inventory.id DESC""")
    rows=cur.fetchall(); cur.execute("SELECT id,title FROM artworks ORDER BY title"); arts=cur.fetchall()
    cur.close(); con.close()
    return render_template("inventory.html",inventory=rows,artworks=arts)

@app.route("/inventory/delete/<int:id>")
def delete_inventory(id):
    if not logged_in(): return redirect(url_for("login"))
    con=db(); cur=con.cursor(); cur.execute("DELETE FROM inventory WHERE id=%s",(id,)); con.commit(); cur.close(); con.close()
    flash("Inventory record deleted!"); return redirect(url_for("inventory"))

if __name__=="__main__":
    app.run(debug=True)
