CREATE DATABASE IF NOT EXISTS art_gallery;
USE art_gallery;

CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) UNIQUE NOT NULL, password VARCHAR(100) NOT NULL);
INSERT INTO users (username,password) VALUES ('admin','admin123');

CREATE TABLE artists (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(100), phone VARCHAR(20), country VARCHAR(50));
CREATE TABLE artworks (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(150) NOT NULL, artist_id INT, category VARCHAR(100), price DECIMAL(10,2), status VARCHAR(50) DEFAULT 'Available', description TEXT, FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE SET NULL);
CREATE TABLE exhibitions (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(150) NOT NULL, start_date DATE, end_date DATE, location VARCHAR(150), description TEXT);
CREATE TABLE exhibition_artworks (id INT AUTO_INCREMENT PRIMARY KEY, exhibition_id INT, artwork_id INT, FOREIGN KEY (exhibition_id) REFERENCES exhibitions(id) ON DELETE CASCADE, FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE);
CREATE TABLE inventory (id INT AUTO_INCREMENT PRIMARY KEY, artwork_id INT, quantity INT DEFAULT 1, location VARCHAR(150), last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, FOREIGN KEY (artwork_id) REFERENCES artworks(id) ON DELETE CASCADE);

INSERT INTO artists (name,email,phone,country) VALUES ('Riya Sharma','riya@gmail.com','9876543210','India'),('Amit Patil','amit@gmail.com','9876501234','India');
INSERT INTO artworks (title,artist_id,category,price,status,description) VALUES ('Nature Beauty',1,'Painting',15000,'Available','A beautiful nature painting.'),('Modern Art',2,'Abstract',25000,'Sold','Modern abstract artwork.');
INSERT INTO exhibitions (name,start_date,end_date,location,description) VALUES ('Indian Art Exhibition','2026-10-01','2026-10-15','Pune Art Gallery','Special Indian art exhibition.');
